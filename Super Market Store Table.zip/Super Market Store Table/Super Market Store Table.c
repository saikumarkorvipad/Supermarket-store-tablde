<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./external.css">
   <link rel="stylesheet" href="./bootstrap/bootstrap.min.css">
    <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"> -->
</head>
<body style="background-color: blueviolet;" class="text-danger" >
    <div class="m-5 bg-info">
    <table class=" table table-hover table-striped">
        <h1 align="center"class="bg-info">SUPERMARKET STORE</h1>
        <thead class="table-primary m-3" align="center">
            <tr>
                <th>Store Location</th>
                <th>Number of employees</th>
                <th>Sales/Sq ft</th>
                
            </tr>
            <tbody align="center">
                <tr>
                    <td style="border: 1px solid;">Anaheim</td>
                    <td style="border: 1px solid;">35</td>
                    <td style="border: 1px solid;">$36</td>
                </tr>
                <tr>
                    <td style="border: 1px solid;">Cerritos</td>
                    <td style="border: 1px solid;">38</td>
                    <td style="border: 1px solid;">$54</td>
                </tr>
                <tr>
                    <td style="border: 1px solid;">Long Beach</td>
                    <td style="border: 1px solid;">42</td>
                    <td style="border: 1px solid;">$67</td>
                </tr>
                <tr>
                    <td style="border: 1px solid;">Santa Ana</td>
                    <td style="border: 1px solid;">27</td>
                    <td style="border: 1px solid;">$37</td>
                </tr>
                <tr class="table-danger">
                    <td style="border: 1px solid;">Total</td>
                    <td style="border: 1px solid;">142</td>
                    <td style="border: 1px solid;">$48</td>
                </tr>
               
        </thead>
    </table> 
    <center>
    <input type="button" class="btn btn-primary" id="CLICK IT" value="CLICK IT" style="margin: 10px;" align="center">
    <input type="button" name="SUBMIT" class="btn btn-primary" id="SUBMIT IT" value="SUBMIT IT" style="padding:15px;" align="center">

</center>
</div>
</body>
</html>